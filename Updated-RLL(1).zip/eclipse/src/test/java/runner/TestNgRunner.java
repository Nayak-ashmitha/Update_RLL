package runner;

import org.testng.annotations.Listeners;

import Listeners.listenerclass;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
      features = {"C:\\Users\\acer\\eclipse\\src\\test\\java\\features\\Myshoppingcart.feature",
                  },
      glue = {"homepage" },
      dryRun = false,
      plugin = {
          "pretty",
          "html:targettestng/cucumberreport_search.html",
          "json:targettestng/cucumber.json",
          "junit:targettestng/xmlReport.xml",
          "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:\", \"timeline:test-output-thread/"
          
        
      },
      monochrome=true
)
@Listeners(listenerclass.class)
public class TestNgRunner extends AbstractTestNGCucumberTests{
	
} 

