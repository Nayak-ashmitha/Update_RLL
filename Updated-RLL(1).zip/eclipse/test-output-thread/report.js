$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"5fc38c4e-cb6a-40d2-96d0-40512ff49a85","feature":"test add to cart","scenario":"add to cart","start":1705696338102,"group":1,"content":"","tags":"@tag,","end":1705696353335,"className":"passed"},{"id":"bcd4a631-d87b-4f1b-9ec7-10842f7ca527","feature":"test add to cart","scenario":"add to cart1","start":1705696353349,"group":1,"content":"","tags":"@tag,","end":1705696361070,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});